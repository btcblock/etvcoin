EtvCoinOMM

EtvCoina pure PoS coin that generates coins from PoS blocks. Except for the first block that produced the first 68 million coins, no PoW mining will get any coins. One billion coins will be evenly distributed to 1,000 people, each with 1 million coins. According to facebook, the cryptocointalk and ecoiner subscriptions are completely free.

Equally distributed to the entire community. Everyone gets 1 million coins, including everyone on the development team. The development team will definitely not be more than others! This is a community coin! Although the development team will maintain and enhance the code and solve any problems, the community will promote and promote coins.

eTVCoino uses a variable PoS ratio with the following annual interest rates: First year: 30% Second year: 20% Third year: 10% Fourth year: 5% Fifth year: 2% From the sixth year: 1 Maintenance year interest%.

     60 seconds blocking time
     Diff repositions each block
     3 transactions confirmed
     50 block confirmation
     PoS prevention lasts for 1 day

Zero Premine.

Port: Connection: 24144 RPC: 24139
